//
//  ViewController.swift
//  Zebra
//
//  Created by Comgen Mac 1 on 06/09/23.
//

import UIKit
import CoreBluetooth


class ViewController: UIViewController, CBCentralManagerDelegate, CBPeripheralDelegate {

    var centralManager: CBCentralManager!
    var peripheral: CBPeripheral?
    var labelHeadder = UILabel()
    var tableView = UITableView()
    var discoveredDevices: [CBPeripheral] = []
    
    var imageView = UIImageView()
    var printButton = UIButton()
    
    var customAlertView: CustomAlertView?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //labelSetup()
       // tableViewSetup()
        
        printImageSetup()
        printButtonSetup()
        
        // Initialize the central manager with the view controller as the delegate
       // centralManager = CBCentralManager(delegate: self, queue: nil)
    }
    
    func printImageSetup(){
        
        imageView.frame = CGRect(x: 20, y: 100, width: view.frame.width/1.15, height: 500)
        imageView.backgroundColor = .clear
        imageView.image = UIImage(named: "img")
        view.addSubview(imageView)
    }
    
    func printButtonSetup() {
        printButton.frame = CGRect(x: 100, y: 700, width: view.frame.width / 2, height: 52)
        printButton.backgroundColor = .systemOrange
        printButton.setTitle("Print", for: .normal)
        printButton.addTarget(self, action: #selector(buttonSetup), for: .touchUpInside)
        view.addSubview(printButton)
    }
    
    @objc func buttonSetup() {
        let printController = UIPrinterPickerController(initiallySelectedPrinter: nil)
        
        printController.present(from: printButton.bounds, in: printButton, animated: true) { (printerPickerController, userDidSelect, error) in
            if userDidSelect {
                //self.printImage()
            } else if let error = error {
                self.showAlert(message: "Error: \(error.localizedDescription)")
            } else {
                self.showAlert(message: "No AirPrint-compatible printer selected. Select Blueetooth Device")
            }
        }
    }

    func showPrinters() {
        let printerPickerController = UIPrinterPickerController(initiallySelectedPrinter: nil)

        printerPickerController.present(animated: true) { (printerPickerController, userDidSelect, error) in
            if userDidSelect {
                let information = UIPrintInfo(dictionary: nil)
                information.outputType = UIPrintInfo.OutputType.general
                information.jobName = "Print View"
                
                let printViewController = UIPrintInteractionController.shared
                printViewController.printInfo = information
                printViewController.printingItem = self.imageView.image
                
                printViewController.print(to: printerPickerController.selectedPrinter!, completionHandler: { (controller, completed, error) in
                    if completed {
                        print("Printing completed successfully.")
                    } else if let error = error {
                        self.showCustomAlert(message: "Error: \(error.localizedDescription)")
                    } else {
                        self.showCustomAlert(message: "Printing was canceled.")
                    }
                })
            } else if let error = error {
                self.showCustomAlert(message: "Error: \(error.localizedDescription)")
            } else {
                self.showCustomAlert(message: "No AirPrint-compatible printer selected.")
            }
        }
    }
    
    func showCustomAlert(message: String) {
        // Create an instance of your custom alert view.
        let customAlertView = CustomAlertView()
        customAlertView.frame = view.bounds
        customAlertView.backgroundColor = UIColor(white: 0, alpha: 0.5) // Semi-transparent background
        
        // Customize your alert view, set the message, and add it to the view.
        // You can add labels, buttons, and other UI elements to your custom alert view here.
        // Example: customAlertView.messageLabel.text = message
        
        view.addSubview(customAlertView)
        
        // Store a reference to the custom alert view for later dismissal if needed.
        self.customAlertView = customAlertView
    }

    
    func showAlert(message: String) {
        let alertController = UIAlertController(title: "Alert", message: message, preferredStyle: .alert)
        
        let okAction = UIAlertAction(title: "OK", style: .default) { [weak self] (_) in
            // When the "OK" button is tapped, initiate Bluetooth device scanning.
          //  self?.bluetoothManager.scanForBluetoothDevices()
            self?.labelSetup()
            self?.tableViewSetup()
            self?.centralManager = CBCentralManager(delegate: self, queue: nil)
            
            print("12345678910")
        }
        
        alertController.addAction(okAction)
        present(alertController, animated: true, completion: nil)
    }


    // MARK: - CBCentralManagerDelegate

    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        if central.state == .poweredOn {
            // Start scanning for nearby Bluetooth peripherals
            centralManager.scanForPeripherals(withServices: nil, options: nil)
        } else {
            // Handle Bluetooth not available or other states
            print("Bluetooth is not available.")
        }
    }

    func centralManager(_ central: CBCentralManager, didDiscover peripheral: CBPeripheral, advertisementData: [String : Any], rssi RSSI: NSNumber) {
        // Check if the discovered peripheral has a name
        guard let deviceName = peripheral.name else {
            return // Skip unnamed devices
        }

        // You can inspect the discovered peripheral here
        print("Discovered Peripheral: \(deviceName)")

        // Add the discovered named peripheral to the array
        if !discoveredDevices.contains(peripheral) {
            discoveredDevices.append(peripheral)

            // Update the label with the count of discovered named devices
            labelHeadder.text = "Available Devices: \(discoveredDevices.count)"

            // Reload the table view to display the updated list of devices
            tableView.reloadData()
        }

        // Connect to the discovered peripheral if it meets your criteria
        if deviceName == "YourPeripheralName" {
            self.peripheral = peripheral
            centralManager.connect(peripheral, options: nil)
        }
    }



        func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
            // Peripheral connected successfully
            print("Connected to Peripheral: \(peripheral.name ?? "Unnamed Peripheral")")
            
            // Obtain and print the peripheral's UUID
            let uuid = peripheral.identifier
            print("Peripheral UUID: \(uuid)")
            
            // Now you can start interacting with the connected peripheral
            // Set the peripheral's delegate to receive notifications from it
            peripheral.delegate = self
            
            // Discover services and characteristics
            peripheral.discoverServices(nil)
        }

    // MARK: - CBPeripheralDelegate

    func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
        if let error = error {
            print("Error discovering services: \(error.localizedDescription)")
            return
        }

        // Iterate through discovered services and discover characteristics if needed
        for service in peripheral.services ?? [] {
            print("Discovered Service: \(service.uuid)")
            
            // Discover characteristics for each service if necessary
            peripheral.discoverCharacteristics(nil, for: service)
        }
    }

    func peripheral(_ peripheral: CBPeripheral, didDiscoverCharacteristicsFor service: CBService, error: Error?) {
        if let error = error {
            print("Error discovering characteristics: \(error.localizedDescription)")
            return
        }

        // Iterate through discovered characteristics and interact with them as needed
        for characteristic in service.characteristics ?? [] {
            print("Discovered Characteristic: \(characteristic.uuid)")
            
            // You can read, write, or subscribe to characteristics here
            // Example: peripheral.readValue(for: characteristic)
        }
    }
    
    func labelSetup(){
        
        labelHeadder.frame = CGRect(x: 30, y: 50, width: 180, height: 80)
        labelHeadder.text = "Available Device"
        view.addSubview(labelHeadder)
    }
    
    func tableViewSetup() {
        
        tableView.frame = CGRect(x: 30, y: 150, width: view.frame.width / 2 + 150, height: view.frame.height * 5)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(TableViewCell.self, forCellReuseIdentifier: "Device")
        view.addSubview(tableView)
        
    }
}



extension ViewController : UITableViewDelegate, UITableViewDataSource {
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return discoveredDevices.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Device", for: indexPath) as! TableViewCell
        let device = discoveredDevices[indexPath.row]
        cell.textLabel?.text = device.name ?? "Unnamed Device"
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        // Retrieve the selected peripheral from the array
        let selectedPeripheral = discoveredDevices[indexPath.row]

        // Connect to the selected peripheral
        centralManager.connect(selectedPeripheral, options: nil)
        
        let alerts = UIAlertController(title: "\(selectedPeripheral.name ?? "")", message:"Connected Successfully" , preferredStyle: .alert)
        let action = UIAlertAction(title: "OK", style: .default)
        alerts.addAction(action)
        present(alerts, animated: true, completion: nil)
    }

//    func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
//        // Peripheral connected successfully
//        print("Connected to Peripheral: \(peripheral.name ?? "Unnamed Peripheral")")
//
//        // Obtain and print the peripheral's UUID
//        let uuid = peripheral.identifier
//        print("Peripheral UUID: \(uuid)")
//
//        // Now you can start interacting with the connected peripheral
//        // Set the peripheral's delegate to receive notifications from it
//        peripheral.delegate = self
//
//        // Discover services and characteristics
//        peripheral.discoverServices(nil)
//    }

    
}
