//
//  Alert_View.swift
//  Zebra
//
//  Created by Comgen Mac 1 on 12/09/23.
//

import Foundation
import UIKit

class CustomAlertView: UIView {
    // Add your alert view UI elements here, such as labels and buttons.
}
